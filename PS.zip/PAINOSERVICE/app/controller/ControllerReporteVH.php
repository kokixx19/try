<?php 
require_once dirname(__FILE__, 3) . "/app/libs/functions.php";
require_once dirname(__FILE__, 3) . "/app/model/ModelTransVehicular.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();

switch($_POST['op'])
{
    case 'list_report';
    $rp = new VehiculoTran;
    $db = $rp->reporte_vh($_POST['placa']);
    echo json_encode($db);
    break;

    case 'insrt_Cliente2';
    $cm=new VehiculoTran;
    $dataDB=$cm->insrt_Cliente2($_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerTper'],$_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerECiv'],$_POST['PerNacion'],$_POST['PerEmail'],$_POST['PerTlfNro']);
    echo $dataDB;

    break;
    case 'insrt_Cliente3';
    $cm=new VehiculoTran;
    $dataDB=$cm->insrt_Cliente3($_POST['PerTIde'],$_POST['PerIdeNro'],$_POST['PerApePat'],$_POST['PerApeMat'],$_POST['PerNom'],$_POST['PerEmail'],$_POST['PerTlfNro']);
    echo $dataDB;

    break;
    case 'insrt_soli';
    $cm=new VehiculoTran;
    $dataDB=$cm->insrt_soli($_POST['TipoPern'],$_POST['PerTideV'],$_POST['PerNroV'],$_POST['Repre_V'],$_POST['PerTideRV'],$_POST['PerNroRV'],$_POST['PerTideC'],$_POST['PerNroC'],$_POST['Repre_C'],$_POST['PerTideRC'],$_POST['PerNroRC'],$_POST['Placa'],$_POST['Moneda'],$_POST['Monto']);
    echo $dataDB;

    break;
}

?>