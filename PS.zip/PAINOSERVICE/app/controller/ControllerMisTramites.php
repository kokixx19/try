<?php
require_once dirname(__FILE__, 3) . "/app/libs/functions.php";
require_once dirname(__FILE__, 3) . "/app/model/ModelMisTramites.php";
header('Access-Control-Allow-Origin: *');
session_start();
$_POST['op'] = isset($_POST['op']) ? $_POST['op'] : die();


switch ($_POST['op']) {
    case 'get_MisTramites';
        $cm=new ModelMisTramites;
        $dataDB=$cm->get_MisTramites($_POST['PerIdenro'],$_POST['FechaInicio'],$_POST['FechaFin']);
        echo json_encode($dataDB);
    break;
    default:
        # code...
        break;


         case 'get_det_MisTramites';
        $cm=new ModelMisTramites;
        $dataDB=$cm->get_det_MisTramites($_POST['kardex'],$_POST['ndoc']);
        echo json_encode($dataDB);
    break;

    case 'get_del_MisTramites';
        $cm=new ModelMisTramites;
        $dataDB=$cm->get_del_MisTramites($_POST['autocod'],$_POST['kardex'],$_POST['dni']);
        echo json_encode($dataDB);
    break;
   
}