<?php
require_once dirname(__FILE__, 3) . "/app/db/DB.php";
require_once dirname(__FILE__, 3) . "/app/services/GeneralServices.php";

 class ModelMisTramites{

  public function __construct()
  {
      $this->db = new Conexion;
  }

  public function get_MisTramites($PerIdenro,$FechaInicio,$FechaFin)
  {
      try {
          $sql = 'Call sp_get_MisTramistes(?,?,?)';
          $param = array($PerIdenro,$FechaInicio,$FechaFin);
          $data = $this->db->query($sql,$param);

          return  $data;
      } catch (Exception $e) {
          $this->Estado = -1;
          $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
          $this->MensajeError = $e->getMessage();
      }
  }


   public function get_det_MisTramites($kardex,$ndoc)
  {
      try {
          $sql = 'Call sp_get_det_MisTramistes(?,?)';
          $param = array($kardex,$ndoc);
          $data = $this->db->query($sql,$param);

          return  $data;
      } catch (Exception $e) {
          $this->Estado = -1;
          $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
          $this->MensajeError = $e->getMessage();
      }
  }
//sp_del_Mistramistes



public function get_del_MisTramites($autocod,$kardex,$dni)
  {
      try {
          $sql = 'Call sp_del_Mistramistes(?,?,?)';
          $param = array($autocod,$kardex,$dni);
          $data = $this->db->query($sql,$param);

          return  $data;
      } catch (Exception $e) {
          $this->Estado = -1;
          $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
          $this->MensajeError = $e->getMessage();
      }
  }

 }