<?php

require_once dirname(__FILE__, 3) . "/app/db/DB.php";
require_once dirname(__FILE__, 3) . "/app/services/GeneralServices.php";

class Combos_Model
{
    public function __construct()
    {
        $this->db = new Conexion;
    }

    public function get_DocsIdentidad()
    {
        try {
            $sql = 'Call sp_get_DocsIdentidad';
           /* $param = array($email, $passw, $ip, $dispo);*/
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_EstadoCivil()
    {
        try {
            $sql = 'Call sp_get_EstadoCivil';
           /* $param = array($email, $passw, $ip, $dispo);*/
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_Nacionalidad()
    {
        try {
            $sql = 'Call sp_get_Nacionalidad';
           /* $param = array($email, $passw, $ip, $dispo);*/
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_Departamento()
    {
        try {
            $sql = 'Call sp_get_Departamento';
           /* $param = array($email, $passw, $ip, $dispo);*/
            $data = $this->db->query($sql);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_Provincia($departamento)
    {
        try {
            $sql = 'Call sp_get_Provincia(?)';
            $param = array($departamento);
            $data = $this->db->query($sql,$param);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

    public function get_Distrito($departamento,$provincia)
    {
        try {
            $sql = 'Call sp_get_Distrito(?,?)';
            $param = array($departamento,$provincia);
            $data = $this->db->query($sql,$param);

            return  $data;
        } catch (Exception $e) {
            $this->Estado = -1;
            $this->Mensaje = 'Error en el proceso, consulte con el administrador.';
            $this->MensajeError = $e->getMessage();
        }
    }

}
