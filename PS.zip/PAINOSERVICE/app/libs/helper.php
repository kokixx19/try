<?php

require_once dirname(dirname(dirname(__FILE__))) . "/app/config.php";

function encryption($string)
{
    $output = false;
    $key = hash('sha256', SECRET_KEY);
    $iv = substr(hash('sha256', SECRET_IV), 0, 16);
    $output = openssl_encrypt($string, METHOD, $key, 0, $iv);
    $output = base64_encode($output);
    return $output;
}

function decryption($string)
{
    $key = hash('sha256', SECRET_KEY);
    $iv = substr(hash('sha256', SECRET_IV), 0, 16);
    $output = openssl_decrypt(base64_decode($string), METHOD, $key, 0, $iv);
    return $output;
}

function fechaCastellano($fecha, $mostrar = null)
{
    $fecha = substr($fecha, 0, 10);
    $numeroDia = date('d', strtotime($fecha));
    $dia = date('l', strtotime($fecha));
    $mes = date('F', strtotime($fecha));
    $anio = date('Y', strtotime($fecha));
    $dias_ES = array("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo");
    $dias_EN = array("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
    $nombredia = str_replace($dias_EN, $dias_ES, $dia);
    $meses_ES = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
    $meses_EN = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    $nombreMes = str_replace($meses_EN, $meses_ES, $mes);
    switch ($mostrar) {
        case 'D':
            return $nombredia;
            break;
        case 'M':
            return $nombreMes;
            break;
        default:
            return $nombredia . " " . $numeroDia . " de " . $nombreMes . " de " . $anio;
            break;
    }
}

function unique_multidim_array($array, $key)
{
    $temp_array = array();
    $i = 0;
    $key_array = array();

    foreach ($array as $val) {
        if (!in_array($val[$key], $key_array)) {
            $key_array[$i] = $val[$key];
            $temp_array[$i] = $val;
        }
        $i++;
    }
    return $temp_array;
}

function insertAfter($matrizOriginal, $elementoNuevo, $after, $comparativa = -1)
{
    $matrizFinal = array();
    foreach ($matrizOriginal as $keyOriginal => $valOriginal) {
        $matrizFinal[] = $valOriginal;
        if ($comparativa == -1) {
            if ($keyOriginal == $after) $matrizFinal[] = $elementoNuevo;
        } else {
            if ($valOriginal[$comparativa] == $after) $matrizFinal[] = $elementoNuevo;
        }
    }
    return $matrizFinal;
}

/* CÓDIGO DE LA FUNCIÓN insertBefore(). */
function insertBefore($matrizOriginal, $elementoNuevo, $before, $comparativa = -1)
{
    $matrizFinal = array();
    foreach ($matrizOriginal as $keyOriginal => $valOriginal) {
        if ($comparativa == -1) {
            if ($keyOriginal == $before) $matrizFinal[] = $elementoNuevo;
        } else {
            if ($valOriginal[$comparativa] == $before) $matrizFinal[] = $elementoNuevo;
        }
        $matrizFinal[] = $valOriginal;
    }
    return $matrizFinal;
}

function getToken($length)
{
    $token = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet .= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet .= "0123456789";
    $max = strlen($codeAlphabet); // edited 
    for ($i = 0; $i < $length; $i++) {
        $token .= $codeAlphabet[random_int(0, $max - 1)];
    }
    return $token;
}

function generarCodigos($cantidad = 3, $longitud = 10, $incluyeNum = true)
{
    $caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if ($incluyeNum)
        $caracteres .= "1234567890";

    $arrPassResult = array();
    $index = 0;
    while ($index < $cantidad) {
        $tmp = "";
        for ($i = 0; $i < $longitud; $i++) {
            $tmp .= $caracteres[rand(0, strlen($caracteres) - 1)];
        }
        if (!in_array($tmp, $arrPassResult)) {
            $arrPassResult[] = $tmp;
            $index++;
        }
    }
    return $tmp;
}

function codigoRandom($inicial = '')
{
    $milisegundos = round(microtime(true) * 1000);
    return $inicial . $milisegundos . rand(1111, 9999);
}

function getRealIP()
{
    if (isset($_SERVER["HTTP_CLIENT_IP"])) {
        return $_SERVER["HTTP_CLIENT_IP"];
    } elseif (isset($_SERVER["HTTP_X_FORWARDED_FOR"])) {

        return $_SERVER["HTTP_X_FORWARDED_FOR"];
    } elseif (isset($_SERVER["HTTP_X_FORWARDED"])) {

        return $_SERVER["HTTP_X_FORWARDED"];
    } elseif (isset($_SERVER["HTTP_FORWARDED_FOR"])) {

        return $_SERVER["HTTP_FORWARDED_FOR"];
    } elseif (isset($_SERVER["HTTP_FORWARDED"])) {

        return $_SERVER["HTTP_FORWARDED"];
    } else {

        return $_SERVER["REMOTE_ADDR"];
    }
}
