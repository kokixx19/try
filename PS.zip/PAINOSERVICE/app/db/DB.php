<?php
require_once dirname(__FILE__, 3) . "/app/config.php";

class Conexion
{
    protected $host = DB_HOST;
    protected $base = DB_NAME;
    protected $user = DB_USER;
    protected $pass = DB_PASS;

    protected $dsn;
    protected $dbh;
    protected $stmt;

    public function __construct($dbname = 'testpaino')
    {
        $this->base = strtolower(trim($dbname)) ? $dbname : DB_NAME;
        try {
            $this->dsn = "mysql:host=" . $this->host . ";dbname=" . $this->base . "; charset=utf8";
            $this->dbh = new PDO($this->dsn, $this->user, $this->pass);
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch (PDOException $e) {
            die("ERROR: " . $e->getMessage());
        }
    }

    public function query($sql, $param = [])
    {
        try {
            $sql = trim($sql);
            if ($sql == '')
                throw new PDOException('SQL FAILED: Query empty');
            $type = strtoupper(substr($sql, 0, 6));
            //  CALL
            if (substr($type, 0, 4) == 'CALL') {
                $this->stmt = null;
                $this->stmt = $this->dbh->prepare($sql);
                if (count($param) > 0) {
                    for ($i = 0; $i < count($param); $i++) {
                        $this->stmt->bindParam($i + 1, $param[$i]);
                    }
                }
                $this->stmt->execute();
                if (strlen(strstr($sql, '@')) > 0)
                    return $this->stmt->closeCursor();
                 // $rows = $this->stmt->rowCount();
                // if ($rows > 0) {
                //     return $this->stmt->fetchAll(PDO::FETCH_BOTH) ?: true;
                // }
                return ($this->stmt->columnCount() > 0) ? $this->stmt->fetchAll(PDO::FETCH_BOTH) : true;
            }
            // SELECT | INSERT | UPDATE | DELETE 
            $this->stmt = $this->dbh->prepare($sql);
            if (count($param) > 0) {
                for ($i = 0; $i < count($param); $i++) {
                    $this->stmt->bindParam($i + 1, $param[$i]);
                }
            }
            switch ($type) {
                case 'SELECT':
                    $this->stmt->execute();
                    if (strlen(strstr($sql, '@')) > 0 || !strlen(strstr($sql, 'FROM')) > 0) {
                        return $this->stmt->fetch(PDO::FETCH_BOTH);
                    } else {
                        return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
                    }
                    break;
                default:
                    $actions = ['INSERT', 'UPDATE', 'DELETE'];
                    return in_array($type, $actions) ? $this->stmt->execute() : false;
                    break;
            }
        } catch (PDOException $e) {
            die("ERROR: " . $e->getMessage());
        }
    }

    public function call($sql, $param = [])
    {
        try {
            $sql = trim($sql);
            if ($sql == '')
                return false;
            $type = strtoupper(substr($sql, 0, 6));
            //  CALL
            if (substr($type, 0, 4) == 'CALL') {
                $this->dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
                $this->stmt = $this->dbh->prepare($sql);
                if (count($param) > 0) {
                    for ($i = 0; $i < count($param); $i++) {
                        $this->stmt->bindParam($i + 1, $param[$i]);
                    }
                }
                if ((strlen(strstr($sql, '@')) > 0)) {
                    $this->stmt->execute();
                    return $this->stmt->closeCursor();
                }
                return $this->stmt->execute();
            }
        } catch (PDOException $e) {
            die("ERROR: " . $e->getMessage());
        }
    }

    public function __destruct()
    {
        $this->dbh = null;
        $this->stmt = null;
    }
}
